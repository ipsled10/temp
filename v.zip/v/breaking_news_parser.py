import mechanize
from bs4 import BeautifulSoup


#start of the epidemic on breakingnews.com http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-03-23

for month in range(3,12):
	if month in [3,5,7,8,10]:
		for day in range(1,32):
			url = mechanize.urlopen("http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-"+str(month)+"-"+str(day))
			soup = BeautifulSoup(url.read())
			print "Date: 2014/"+str(month)+"/"+str(day)
			with open("breaking_news_from_start_new.txt","a") as file:
				file.write("Date: 2014/"+str(month)+"/"+str(day))
			for item in soup.find_all("div",{"class" : "headline"}):
				with open("breaking_news_from_start4_new.txt","a") as file:
					file.write(item.text.encode("utf-8")  + "\n")
				#print item.text + "\n"
	else:
		for day in range(1,31):
			url = mechanize.urlopen("http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-"+str(month)+"-"+str(day))
			soup = BeautifulSoup(url.read())
			print "Date: 2014/"+str(month)+"/"+str(day)
			with open("breaking_news_from_start_new.txt4","a") as file:
				file.write("Date: 2014/"+str(month)+"/"+str(day))
			for item in soup.find_all("div",{"class" : "headline"}):
				with open("breaking_news_from_start_new.txt","a") as file:
					file.write(item.text.encode("utf-8") + "\n")
 				#print item.text + "\n"

	