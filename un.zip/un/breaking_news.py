import mechanize,urllib2
from bs4 import BeautifulSoup

def collecto():
	
	data = mechanize.urlopen("http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/")
	soup = BeautifulSoup(data.read())

collecto()


http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-10-10+16%3A50%3A39.040778%2B00%3A00

http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-10-09+18%3A36%3A09.615843%2B00%3A00


http://www.breakingnews.com/topic/africa-ebola-outbreak-2014/?date__lt=2014-09-17

# then manipulate the numbers and download all headlines to use as training tweet