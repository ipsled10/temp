// Facebook buttons
window.fbsdk = (function(d, s, id){
  var t, js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s);
  js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=614363621951718";
  fjs.parentNode.insertBefore(js, fjs);
  return window.fbsdk || (t = {
      _e: [],
      ready: function (f) {
          t._e.push(f)
      }
  });
}(document, 'script', 'facebook-jssdk'));

$(fbsdk).ready(function (fbsdk) {
  _ga.trackFacebook();
});

// Twitter buttons
window.twttr = (function (d, s, id) {
  var t, js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s);
  js.id = id;
  js.src = "//platform.twitter.com/widgets.js";
  fjs.parentNode.insertBefore(js, fjs);
  return window.twttr || (t = {
      _e: [],
      ready: function (f) {
          t._e.push(f)
      }
  });
}(document, "script", "twitter-wjs"));

$(twttr).ready(function (twttr) {
  _ga.trackTwitter();
});


// Google+ buttons
(function() {
  var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
  po.src = 'https://apis.google.com/js/plusone.js';
  var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
}());


// Storify buttons
/*
(function() {
  var s = document.createElement('SCRIPT'), s1 = document.getElementsByTagName('SCRIPT')[0];
  s.type = 'text/javascript';
  s.async = true;
  s.src = '//storify.com/js/storifythis.js';

  s1.parentNode.insertBefore(s, s1);
}());
*/


// Tumblr buttons
(function() {
  var s = document.createElement('SCRIPT'), s1 = document.getElementsByTagName('SCRIPT')[0];
  s.type = 'text/javascript';
  s.async = true;
  s.src = '//platform.tumblr.com/v1/share.js';

  s1.parentNode.insertBefore(s, s1);
}());


// Nielsen tracking
(function () {
  var d = new Image(1, 1);
  d.onerror = d.onload = function () {
    d.onerror = d.onload = null;
  };
  d.src = ["//secure-us.imrworldwide.com/cgi-bin/m?ci=us-505401h&cg=0&cc=1&si=", escape(window.location.href), "&rp=", escape(document.referrer), "&ts=compact&rnd=", (new Date()).getTime()].join('');
}());


// comScore tracking
var _comscore = _comscore || [];
_comscore.push({ c1: "2", c2: "3000001" });
(function() {
  var s = document.createElement("script"), el = document.getElementsByTagName("script")[0]; s.async = true;
  s.src = (document.location.protocol == "https:" ? "https://sb" : "http://b") + ".scorecardresearch.com/beacon.js";
  el.parentNode.insertBefore(s, el);
}());


// Chartbeat tracking
/*
var _sf_async_config={};
_sf_async_config.uid = 4176;
_sf_async_config.domain = "breakingnews.com";
(function(){
  function loadChartbeat() {
    window._sf_endpt=(new Date()).getTime();
    var e = document.createElement("script");
    e.setAttribute("language", "javascript");
    e.setAttribute("type", "text/javascript");
    e.setAttribute('src', '//static.chartbeat.com/js/chartbeat.js');
    document.body.appendChild(e);
  }
  var oldonload = window.onload;
  window.onload = (typeof window.onload != "function") ?
     loadChartbeat : function() { oldonload(); loadChartbeat(); };
})();
*/

